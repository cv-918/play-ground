var class_combat =
[
    [ "Combat", "class_combat.html#af15a4367516c5d59952b66309448d85c", null ],
    [ "GetDamage", "class_combat.html#a043a23c92d4b888152b44dffd72f5882", null ],
    [ "status_", "class_combat.html#a10ca8e8b6a7091605c749e07f15b6549", null ]
];