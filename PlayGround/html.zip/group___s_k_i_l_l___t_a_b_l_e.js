var group___s_k_i_l_l___t_a_b_l_e =
[
    [ "SkillJsonInfo::id_", "group___s_k_i_l_l___t_a_b_l_e.html#gaa8a4551d7a273c3fcea3c8869fe1617a", null ],
    [ "SkillJsonInfo::name_", "group___s_k_i_l_l___t_a_b_l_e.html#gae1be667a28f91cf86b982536a14c48ac", null ],
    [ "SkillJsonInfo::desc_", "group___s_k_i_l_l___t_a_b_l_e.html#gaade874f9b58c959bb08b8d2425200889", null ],
    [ "SkillJsonInfo::type_", "group___s_k_i_l_l___t_a_b_l_e.html#gacab6989655feb04e48a1e8751d63e8e4", null ],
    [ "SkillJsonInfo::max_lv_", "group___s_k_i_l_l___t_a_b_l_e.html#ga7d94ef3282aa5637208390409cd3a6a5", null ],
    [ "SkillJsonInfo::unlock_type_", "group___s_k_i_l_l___t_a_b_l_e.html#ga221d4ef8be567562cd0cca081c666182", null ],
    [ "SkillJsonInfo::cooldown_", "group___s_k_i_l_l___t_a_b_l_e.html#ga11be194c07a3939010b60b5d70362189", null ],
    [ "SkillJsonInfo::duration_", "group___s_k_i_l_l___t_a_b_l_e.html#ga5b3047920b768f4b0375f78ec4e9fd4b", null ],
    [ "SkillJsonInfo::dot_interval_", "group___s_k_i_l_l___t_a_b_l_e.html#ga56d88748bafe76dbf13c870dad9bd878", null ],
    [ "SkillJsonInfo::area_of_effect_", "group___s_k_i_l_l___t_a_b_l_e.html#ga93cd7c29b3af36461eacd77d6d95ba44", null ],
    [ "SkillJsonInfo::damage_multiplier_", "group___s_k_i_l_l___t_a_b_l_e.html#ga71235d98dad1da973b8ef7ef5d233d9b", null ],
    [ "SkillJsonInfo::flat_damage_", "group___s_k_i_l_l___t_a_b_l_e.html#ga0d1b69cf4f38b499f13276bde26b7348", null ],
    [ "SkillJsonInfo::proj_count_", "group___s_k_i_l_l___t_a_b_l_e.html#gab09c61b56dd97ed03468c7f9d94f26d7", null ],
    [ "SkillJsonInfo::proj_speed_", "group___s_k_i_l_l___t_a_b_l_e.html#ga7c8d9e30cd2ff0e6fffc31a9b49ebd70", null ],
    [ "SkillJsonInfo::proj_lifetime_", "group___s_k_i_l_l___t_a_b_l_e.html#ga8ebd938f30ce12385d18b9195cae9747", null ],
    [ "SkillJsonInfo::proj_size_", "group___s_k_i_l_l___t_a_b_l_e.html#ga422eead2cdf6f1dfbc43866db44a3cfb", null ]
];