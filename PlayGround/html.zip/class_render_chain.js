var class_render_chain =
[
    [ "~RenderChain", "class_render_chain.html#ab7ef89125d8a30d9aa4f59c0884c354a", null ],
    [ "Initialize", "class_render_chain.html#a8eed4b1839af050f977e27bb32e76326", null ],
    [ "Clear", "class_render_chain.html#a9ddd72c80f7213283ed65930e420c594", null ],
    [ "Present", "class_render_chain.html#a1fe1204f9a261578c686cd8d9ab9b8de", null ],
    [ "_CreateBackBuffer", "class_render_chain.html#af217aa2640c1c4e4d271032e07299e27", null ],
    [ "_DestroyBackBuffer", "class_render_chain.html#a99a2685bb950e2fcd7a25fade3f6f434", null ],
    [ "back_bmp_", "class_render_chain.html#ad77539b78bb02ac4a302a700b440e89b", null ],
    [ "old_back_bmp_", "class_render_chain.html#a9bec34472fd753775e2334244ca2e285", null ],
    [ "m_gdiplusToken", "class_render_chain.html#a127d038070fac08f8fede8b340d6262a", null ]
];