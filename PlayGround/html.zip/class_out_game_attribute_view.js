var class_out_game_attribute_view =
[
    [ "OutGameAttributeView", "class_out_game_attribute_view.html#a0cfc118527db9012dabace9ed46745a5", null ],
    [ "Update", "class_out_game_attribute_view.html#aebfb076ce4b40853f6f53d8fd510b393", null ],
    [ "Render", "class_out_game_attribute_view.html#aaf56dacfb6c44ce97e4d5f68775d043d", null ],
    [ "return_btn_", "class_out_game_attribute_view.html#ac28e4f2969db8c480eca0d64a89661c5", null ]
];