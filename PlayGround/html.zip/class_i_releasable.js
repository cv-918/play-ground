var class_i_releasable =
[
    [ "IReleasable", "class_i_releasable.html#a926fde3b0df83f76b927474f1363e653", null ],
    [ "~IReleasable", "class_i_releasable.html#a3aa8057071318622075b840caa9a58f3", null ],
    [ "Release", "class_i_releasable.html#ad61773ef9ba266e91fbb1124e378c434", null ]
];