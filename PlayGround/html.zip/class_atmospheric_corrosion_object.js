var class_atmospheric_corrosion_object =
[
    [ "AtmosphericCorrosionObject", "class_atmospheric_corrosion_object.html#ada53f4f17142e71dc65d67e7d58dd11f", null ],
    [ "Initialize", "class_atmospheric_corrosion_object.html#a6824576027a5abc740c979eddc240cda", null ],
    [ "Update", "class_atmospheric_corrosion_object.html#a7ab375f58d631ebe8965c7b8ba4cfe39", null ],
    [ "OnDestroy", "class_atmospheric_corrosion_object.html#a55c07f91fd1d7a54d8dac3edd93d28b7", null ],
    [ "OnCollisionEnter", "class_atmospheric_corrosion_object.html#a3161a1332f29d6e2516ec80850e98e9c", null ],
    [ "OnCollisionStay", "class_atmospheric_corrosion_object.html#a985cb302dc04755ab15de43ed0c3723c", null ],
    [ "AttackEnemy", "class_atmospheric_corrosion_object.html#a4486c8ad9b22144c291a3857430a8657", null ],
    [ "life_timer_", "class_atmospheric_corrosion_object.html#a23738601a0253a26b692de530dac4b2f", null ],
    [ "is_movement_disabled_", "class_atmospheric_corrosion_object.html#a377c446a7ec82a447dfa11902268c88c", null ],
    [ "collider_", "class_atmospheric_corrosion_object.html#a21892b981463f4a5d5e1b6d14b6cc51a", null ],
    [ "affected_movements_", "class_atmospheric_corrosion_object.html#ab91aa57ce17b84523796b20942b73c2b", null ]
];