var _interfaces_8h =
[
    [ "ISingleton&lt; T &gt;", "class_i_singleton.html", "class_i_singleton" ],
    [ "IInitializable", "class_i_initializable.html", "class_i_initializable" ],
    [ "IUpdatable", "class_i_updatable.html", "class_i_updatable" ],
    [ "IDestroyable", "class_i_destroyable.html", "class_i_destroyable" ],
    [ "IIdentifiable", "class_i_identifiable.html", "class_i_identifiable" ],
    [ "IHandler", "class_i_handler.html", "class_i_handler" ],
    [ "ICollidable", "class_i_collidable.html", "class_i_collidable" ],
    [ "IDamagable", "class_i_damagable.html", "class_i_damagable" ],
    [ "MAKE_INITIALIZED", "_interfaces_8h.html#af25ab2f37742e25c6f65b39f1f76d1e6", null ],
    [ "HandlerSystemList", "_interfaces_8h.html#a12e3a7f75fdfc2f744531415c89e5fe3", [
      [ "Collision", "_interfaces_8h.html#a12e3a7f75fdfc2f744531415c89e5fe3a15fb6ccbd11ebebcea2b48dc477f3561", null ],
      [ "Damage", "_interfaces_8h.html#a12e3a7f75fdfc2f744531415c89e5fe3ab9f24e83531326204197015b2f43a93f", null ],
      [ "SystemCount", "_interfaces_8h.html#a12e3a7f75fdfc2f744531415c89e5fe3a49e51991eae1fbf09e655967ad53d7eb", null ]
    ] ]
];