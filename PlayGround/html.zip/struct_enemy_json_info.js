var struct_enemy_json_info =
[
    [ "tier_", "struct_enemy_json_info.html#a81d0b1f01c6a57d32bba2a93bcba89bd", null ],
    [ "role_", "struct_enemy_json_info.html#ae2b9810a8fffd99b6a5869a8394a61d9", null ],
    [ "exp_reward_", "struct_enemy_json_info.html#aed13fd61d07a74270574932e2f48997e", null ],
    [ "dust_reward_", "struct_enemy_json_info.html#aaa73fd69ad9e28be7c956e624ddbb4ec", null ],
    [ "dust_resource_count_", "struct_enemy_json_info.html#a06ae85b505fb0bfab324feb550ad2b5e", null ],
    [ "projectile_pattern_", "struct_enemy_json_info.html#a13bbb9f51823f33d40fcf265a05f3bd3", null ],
    [ "projectile_damage_", "struct_enemy_json_info.html#ab423cb5e5c5701f93e07dced5031869e", null ],
    [ "projectile_speed_", "struct_enemy_json_info.html#acc3717d026d4210c557e3e4e0f29cd76", null ],
    [ "movement_pattern_", "struct_enemy_json_info.html#ae9b9aed4f7c38ea0f3711c764d541189", null ],
    [ "move_speed_unit_", "struct_enemy_json_info.html#a209db0446313bce6e0868b20ddb8a04e", null ]
];