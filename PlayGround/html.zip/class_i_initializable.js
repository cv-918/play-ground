var class_i_initializable =
[
    [ "IInitializable", "class_i_initializable.html#a446d2b84654605da3782e77610fea2e7", null ],
    [ "~IInitializable", "class_i_initializable.html#a8d84d907f35c947fed66e1171cce80ca", null ],
    [ "Initialize", "class_i_initializable.html#ac02bb375ded521bd8ae9478ccb02b60c", null ],
    [ "IsInitialized", "class_i_initializable.html#ab6781d4a2d8190b9aacf6e2f2e286d4b", null ],
    [ "_MarkAsInitialized", "class_i_initializable.html#a535561fce6c5ec7ac1d78bb2f5c579d4", null ],
    [ "initialized_", "class_i_initializable.html#aec727d889c57df98202ede1860318617", null ]
];