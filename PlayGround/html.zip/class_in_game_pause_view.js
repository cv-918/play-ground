var class_in_game_pause_view =
[
    [ "InGamePauseView", "class_in_game_pause_view.html#ab7c03e94d8b26f1c4c89ee7db18ef7d2", null ],
    [ "Render", "class_in_game_pause_view.html#a8f043826724ae7c251f90afc21e9628c", null ]
];