var struct_stage_spawn_pool_json_info =
[
    [ "id_", "struct_stage_spawn_pool_json_info.html#a3755dc6744f51f403d3702e7e9cc48fb", null ],
    [ "spawn_enemies_info_", "struct_stage_spawn_pool_json_info.html#ae243ad5450ac006c2c1dbba9ebe2956b", null ]
];