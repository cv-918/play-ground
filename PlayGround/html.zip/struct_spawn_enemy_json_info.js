var struct_spawn_enemy_json_info =
[
    [ "id_", "struct_spawn_enemy_json_info.html#a37525150b0f317cfcda3fd089ea2b003", null ],
    [ "weight_", "struct_spawn_enemy_json_info.html#af8f0635d0807e481255f74a0878bb1b5", null ],
    [ "spawn_interval_", "struct_spawn_enemy_json_info.html#ad14090959aff48eea4ea3c33882577d0", null ]
];