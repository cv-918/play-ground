var class_scene_manager =
[
    [ "~SceneManager", "class_scene_manager.html#a2bb376a85d29e85f47753e26c7539229", null ],
    [ "Initialize", "class_scene_manager.html#aa1e3315adf9fe6f3a95d089603b98bd4", null ],
    [ "Update", "class_scene_manager.html#a393b219b0885e2f8ddd25162fb07a779", null ],
    [ "LateUpdate", "class_scene_manager.html#a6a102794f7a15221bbb942ca107c575d", null ],
    [ "Render", "class_scene_manager.html#a291742bd0cc1ffa7920ebf5dae9e42e0", null ],
    [ "ChangeScene", "class_scene_manager.html#a1d8c40a35a832d9c84f886ee0e80a056", null ],
    [ "_CreateNextScene", "class_scene_manager.html#ab24a371e6c357a0dd4e31480a887d88c", null ],
    [ "_CleanupCurrentScene", "class_scene_manager.html#aa2e20841fcc67d9792ea9bab9d07ce87", null ],
    [ "_GetSceneName", "class_scene_manager.html#a7105dbbce35b3b6f0bb00afb7566f9df", null ],
    [ "curr_scene_", "class_scene_manager.html#a108f60a199972c3a94a3a0c3132c929e", null ],
    [ "curr_scene_type_", "class_scene_manager.html#a4618c49366fac940877fe7db104ccddb", null ],
    [ "next_scene_type_", "class_scene_manager.html#a1e4b2c20cb1e3b305eaeb3f670c74a7d", null ],
    [ "scene_history_", "class_scene_manager.html#a20459a10fbca4416e8d1a9c92ba22e61", null ]
];