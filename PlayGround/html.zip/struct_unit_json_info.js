var struct_unit_json_info =
[
    [ "id_", "struct_unit_json_info.html#abb2075fb66fe5439e847ea5b107b6ef2", null ],
    [ "name_", "struct_unit_json_info.html#a245dccb01156a06c0ed55cb5364814ff", null ],
    [ "body_size_", "struct_unit_json_info.html#a7abcf84622213f7b28684fe41be55c73", null ],
    [ "attack_speed_", "struct_unit_json_info.html#ac11eb31ff4de435aa16049ca277ab97b", null ],
    [ "hp_", "struct_unit_json_info.html#a9e645b303d2a8c8e10c7161755b411be", null ],
    [ "contact_damage_", "struct_unit_json_info.html#ad7a894c09738d97cdff55149172d2f41", null ]
];