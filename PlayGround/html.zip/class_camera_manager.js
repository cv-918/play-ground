var class_camera_manager =
[
    [ "Update", "class_camera_manager.html#a7bfccb4cad13422c56e7ded9a6aad787", null ],
    [ "Shake", "class_camera_manager.html#aada3f68843dee7e40a28cf906cc9e45b", null ],
    [ "GetOffset", "class_camera_manager.html#a04cb4c6fdd532a381cabf5e6ae7930d2", null ],
    [ "shake_intensity_", "class_camera_manager.html#a03342c7567fc511993acec8dd9929901", null ],
    [ "shake_duration_", "class_camera_manager.html#a84946f2ee274932dbaf056108e3bd2f6", null ],
    [ "camera_offset_", "class_camera_manager.html#aceb45c98fa66f000941ffdbf7b5a25de", null ]
];