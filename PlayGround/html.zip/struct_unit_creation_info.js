var struct_unit_creation_info =
[
    [ "position_", "struct_unit_creation_info.html#a20cd645b8dd4efd1236dad56bb44ddb9", null ],
    [ "look_point_", "struct_unit_creation_info.html#ab5c56e5e856ec62ebc33a4389b4269a6", null ],
    [ "stat_multiplier_", "struct_unit_creation_info.html#aa98d162229fe544e7e4a14c0a4d264df", null ],
    [ "owner_", "struct_unit_creation_info.html#aacfcef654f58503872c3cae72e4ab103", null ]
];