var struct_attribute_node_json_info =
[
    [ "id_", "struct_attribute_node_json_info.html#aa5bc18c4cac1467890c77bed56829665", null ],
    [ "name_", "struct_attribute_node_json_info.html#a9e46e6982f0325f63e96c39d9b77db74", null ],
    [ "desc_", "struct_attribute_node_json_info.html#ab37e37fbf3e2de84393978478b2463e8", null ],
    [ "max_lv_", "struct_attribute_node_json_info.html#a192b59e082ac1e03adb114b45634a378", null ],
    [ "grade_", "struct_attribute_node_json_info.html#a021bc69758f02e26677f71cda72b866f", null ],
    [ "tier_", "struct_attribute_node_json_info.html#a74eae52968f688ea71213f94ea178075", null ],
    [ "cost_", "struct_attribute_node_json_info.html#a3377bc1cb43b3b711883c10e99cf55c6", null ],
    [ "cost_growth_rate_", "struct_attribute_node_json_info.html#a296161a548f6dc858ec6f27526148628", null ],
    [ "stat_type_", "struct_attribute_node_json_info.html#ac08134114910cdaaadb2d8c0fdebf388", null ],
    [ "stat_value_", "struct_attribute_node_json_info.html#a3f32c648680c91a8c3ac69c9a62291fc", null ],
    [ "special_ability_id_", "struct_attribute_node_json_info.html#aaa0f0de783dc6eb7da9df7c81ed373ed", null ],
    [ "calc_type_", "struct_attribute_node_json_info.html#ad7f831d032d5ae09225dbe5c3d4e80b4", null ],
    [ "unlock_character_id_", "struct_attribute_node_json_info.html#aff89361c514a2ff08ff4511c91e7e2b1", null ],
    [ "parent_node_id_", "struct_attribute_node_json_info.html#a98e04f7ca75d18c7dcb159fda186bedf", null ],
    [ "required_parent_node_lv_", "struct_attribute_node_json_info.html#afd31224c88f11645a7fafb05a54cc2a4", null ],
    [ "children_nodes_info_", "struct_attribute_node_json_info.html#a428e69fe75ea421291c1c13f2b5af947", null ]
];