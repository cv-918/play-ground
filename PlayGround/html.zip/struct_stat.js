var struct_stat =
[
    [ "Stat", "struct_stat.html#ae928e5dc2e02aa907902d4f3b369ab4a", null ],
    [ "GetTotalIncrease", "struct_stat.html#a63dc9969921e815bbe703e2c9a18c624", null ],
    [ "is_additive_active_", "struct_stat.html#ac4bc7f72370f995f19395b3eab2f14ff", null ],
    [ "additive_increase_", "struct_stat.html#a492fc9701a4cea9e9cb303776ef3836e", null ],
    [ "is_multiplicative_active_", "struct_stat.html#a4b41462fc52cc0bde4ce9a1f61437bae", null ],
    [ "multiplicative_increase_rate_", "struct_stat.html#a186f61f0aacded63780607543e6900ca", null ]
];