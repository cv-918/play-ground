var group___common =
[
    [ "SkillJsonInfo::cooldown_", "group___common.html#ga11be194c07a3939010b60b5d70362189", null ],
    [ "SkillJsonInfo::duration_", "group___common.html#ga5b3047920b768f4b0375f78ec4e9fd4b", null ],
    [ "SkillJsonInfo::max_lv_", "group___common.html#ga7d94ef3282aa5637208390409cd3a6a5", null ],
    [ "SkillJsonInfo::type_", "group___common.html#gacab6989655feb04e48a1e8751d63e8e4", null ],
    [ "SkillJsonInfo::unlock_type_", "group___common.html#ga221d4ef8be567562cd0cca081c666182", null ]
];