var struct_run_session_result =
[
    [ "is_cleared_", "struct_run_session_result.html#aa292db6cb2f60df57544642bb6ea84d0", null ],
    [ "earned_coin_count_", "struct_run_session_result.html#abce908ddfeb59cd7ba6947359e91ba40", null ],
    [ "gained_experience_", "struct_run_session_result.html#a6276e986f4a21bca947dc40ed741c6d5", null ],
    [ "play_time_", "struct_run_session_result.html#a3ae6bb6e9fed759b56fb48e880fde4c2", null ]
];