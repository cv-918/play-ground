var _unit_base_8h =
[
    [ "UnitBase", "class_unit_base.html", "class_unit_base" ],
    [ "UnitDefaultColliderId", "_unit_base_8h.html#a0f8a76ba30017e7c94afd402b9592824", [
      [ "Body", "_unit_base_8h.html#a0f8a76ba30017e7c94afd402b9592824aac101b32dda4448cf13a93fe283dddd8", null ],
      [ "Attack", "_unit_base_8h.html#a0f8a76ba30017e7c94afd402b9592824adcfafcb4323b102c7e204555d313ba0a", null ],
      [ "ColCount", "_unit_base_8h.html#a0f8a76ba30017e7c94afd402b9592824a7e97ca267237f36265513b7a28f23525", null ]
    ] ]
];