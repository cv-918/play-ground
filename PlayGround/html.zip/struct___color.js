var struct___color =
[
    [ "_Color", "struct___color.html#ac5bdb33287e90f8310b96f07187a94e1", null ],
    [ "_Color", "struct___color.html#a4a9645c09a105e035f00c49c5033ef0d", null ],
    [ "_Color", "struct___color.html#a1ed52845bb17e5b7be1a66ecddbecb81", null ],
    [ "_Color", "struct___color.html#a916aa7ccda8bf44327fb34920cace5b0", null ],
    [ "SetAlpha", "struct___color.html#a66123446690e046e2b408540e38d3899", null ]
];