var class_props =
[
    [ "Props", "class_props.html#aad94e84319430138ab4de4f3b47b14f2", null ],
    [ "ChangeState", "class_props.html#a9f3e125edaf7771e2c1342e034266ad0", null ],
    [ "type_", "class_props.html#a4efea08409d7d4d05f724abcebaacb8e", null ],
    [ "creation_info_", "class_props.html#a2fef60ae07fc79bb19ada394b3ee9fed", null ],
    [ "state_", "class_props.html#a37f85a4f13111343b5ced40cde305a20", null ]
];