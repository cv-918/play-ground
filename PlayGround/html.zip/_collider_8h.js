var _collider_8h =
[
    [ "Collider", "class_collider.html", "class_collider" ],
    [ "ColliderType", "_collider_8h.html#a7f138e75fc3cc79e825c39e040690395", [
      [ "Sphere", "_collider_8h.html#a7f138e75fc3cc79e825c39e040690395ab7095f057db3fefa7325ad93a04e14fd", null ],
      [ "Rectangle", "_collider_8h.html#a7f138e75fc3cc79e825c39e040690395ace9291906a4c3b042650b70d7f3b152e", null ],
      [ "Ellipse", "_collider_8h.html#a7f138e75fc3cc79e825c39e040690395a119518c2134c46108179369f0ce81fa2", null ],
      [ "None", "_collider_8h.html#a7f138e75fc3cc79e825c39e040690395a6adf97f83acf6453d4a6a4b1070f3754", null ]
    ] ]
];