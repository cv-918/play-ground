var class_i_damagable =
[
    [ "IDamagable", "class_i_damagable.html#ad9ef04abdabc259096d8e00f5afd2b01", null ],
    [ "~IDamagable", "class_i_damagable.html#a48fd6bb9465e9bf8a94d064794192f06", null ],
    [ "GetDamage", "class_i_damagable.html#ab743a0219ac488cbc908478adb910dee", null ]
];