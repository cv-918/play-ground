var class_graphic_resource_manager =
[
    [ "GraphicResourceManager", "class_graphic_resource_manager.html#a9dea8b088b062d724205bf15ca8adc07", null ],
    [ "~GraphicResourceManager", "class_graphic_resource_manager.html#af2fd39fb4bfec7824a7e413469297ce1", null ],
    [ "GetBrush", "class_graphic_resource_manager.html#adc3874a207836c72edbea33b9716d445", null ],
    [ "GetBrush", "class_graphic_resource_manager.html#a6c35057c25eb69bc59e4188a9e108a0a", null ],
    [ "GetPen", "class_graphic_resource_manager.html#aedd5b6e516ca76c6873196a61bf74063", null ],
    [ "GetPen", "class_graphic_resource_manager.html#a71a72ab1fa4804dfc0961986ab8dcec8", null ],
    [ "GetFont", "class_graphic_resource_manager.html#a44a23bad020b24db9667fdcb48432762", null ],
    [ "GetTexture", "class_graphic_resource_manager.html#a05ca2e55ac10b6826e0cfb4915a77bdf", null ],
    [ "GetTextureBrush", "class_graphic_resource_manager.html#a1a4fb858a2e0470d4962f80a90e6d572", null ],
    [ "GetTextureBrush", "class_graphic_resource_manager.html#a598b0508338e512cef9ce482f0130188", null ],
    [ "GetStringFormat", "class_graphic_resource_manager.html#a45236eae9ae52d567cfcf2c0df483a1b", null ],
    [ "Release", "class_graphic_resource_manager.html#a4dfcf905a518d79b436e444db805a8ba", null ],
    [ "brushes_", "class_graphic_resource_manager.html#a3642ebe009595d72ce1881f57923b95d", null ],
    [ "pens_", "class_graphic_resource_manager.html#ae674afa0ec430ce91dade6065b05a907", null ],
    [ "fonts_", "class_graphic_resource_manager.html#a2c4bc98377f6d3ceb0a66f2b3cc6a56b", null ],
    [ "textures_", "class_graphic_resource_manager.html#ade2a1677de062c7b515f5b96343ad337", null ],
    [ "tex_brushes_", "class_graphic_resource_manager.html#a8a86e9ff797adf5e869a846d35336608", null ],
    [ "format_center_", "class_graphic_resource_manager.html#a77909a7abb595e7ff60c433c66affc0d", null ],
    [ "format_left_", "class_graphic_resource_manager.html#a2e10bf4404b42ec53ea680c52016a856", null ]
];