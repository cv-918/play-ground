var _particle_data_8h =
[
    [ "ParticleSetting", "struct_particle_setting.html", "struct_particle_setting" ],
    [ "Particle", "struct_particle.html", "struct_particle" ],
    [ "EmitterShape", "_particle_data_8h.html#a105e4796db00caedfe573616f81d7276", [
      [ "Point", "_particle_data_8h.html#a105e4796db00caedfe573616f81d7276a2a3cd5946cfd317eb99c3d32e35e2d4c", null ],
      [ "Circle", "_particle_data_8h.html#a105e4796db00caedfe573616f81d7276a30954d90085f6eaaf5817917fc5fecb3", null ],
      [ "Box", "_particle_data_8h.html#a105e4796db00caedfe573616f81d7276a3cfce651e667ab85486dd42a8185f98a", null ]
    ] ],
    [ "to_json", "_particle_data_8h.html#a0226993763a0868a1af3b5cbb414d880", null ],
    [ "from_json", "_particle_data_8h.html#a71936048367f97c361402df6ab98677c", null ]
];