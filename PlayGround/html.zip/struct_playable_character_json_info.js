var struct_playable_character_json_info =
[
    [ "attack_range_", "struct_playable_character_json_info.html#ad2f90beada53dbe16858ca68bf5687c3", null ],
    [ "collector_size_", "struct_playable_character_json_info.html#a491ffbaecb45107e0fd946da9bbc50a7", null ],
    [ "move_speed_max_", "struct_playable_character_json_info.html#a8c0f03c406e53c9bff20312133876c7a", null ],
    [ "acceleration_", "struct_playable_character_json_info.html#a509d036cc01cd4e56dcf55e4659fedf7", null ],
    [ "friction_", "struct_playable_character_json_info.html#a26d6c2f7cb017925e63b75196850dd8a", null ]
];