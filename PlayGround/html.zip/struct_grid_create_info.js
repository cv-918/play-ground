var struct_grid_create_info =
[
    [ "cell_size", "struct_grid_create_info.html#af9aea5c87d04ed285ab81e4c2ea72441", null ],
    [ "cols", "struct_grid_create_info.html#a318957678b46f6bb64f65946e0f80b22", null ],
    [ "line_color", "struct_grid_create_info.html#a0ebe0e9e1fc21110063d3a3b24157f2c", null ],
    [ "line_thickness", "struct_grid_create_info.html#aca2486413f066ea660abf2a339b0e26a", null ],
    [ "rows", "struct_grid_create_info.html#aa48dcf593743762a6444b7ad05cd07f4", null ]
];