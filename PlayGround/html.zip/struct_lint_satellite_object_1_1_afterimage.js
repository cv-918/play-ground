var struct_lint_satellite_object_1_1_afterimage =
[
    [ "position", "struct_lint_satellite_object_1_1_afterimage.html#a6b066de2a7c7a68511953580e11289d4", null ],
    [ "alpha", "struct_lint_satellite_object_1_1_afterimage.html#ae54b48b5f66ae1dd1d53a8a6e368aeb3", null ]
];