var struct_attribute_stat =
[
    [ "GetStat", "struct_attribute_stat.html#a14ba0a4029c475dac41086f848ec6ff7", null ],
    [ "GetStats", "struct_attribute_stat.html#a5b94bbb2511a0df50555314adbc877c7", null ],
    [ "IncreaseStat", "struct_attribute_stat.html#a23984e6aa365a16ad8ed244d22e81322", null ],
    [ "special_ability_dust_collect_", "struct_attribute_stat.html#a2eedc2222a896a1d96a9874d9b97c987", null ],
    [ "attribute_stats_", "struct_attribute_stat.html#a8c2e8d6d6e6ee3734c67354174e33db6", null ]
];