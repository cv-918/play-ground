var class_in_game_result_view =
[
    [ "InGameResultView", "class_in_game_result_view.html#a2f68957ca50507f2761623d8a8c1843b", null ],
    [ "Render", "class_in_game_result_view.html#a3ae88137f840821ee5524dcbf313b3fa", null ]
];