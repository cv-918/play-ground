var class_i_handler =
[
    [ "IHandler", "class_i_handler.html#a57a9bf3d1948a90df6f96d74514b4922", null ],
    [ "~IHandler", "class_i_handler.html#a5491dcf6df736886f76c58d957245e16", null ]
];