var class_particle_service =
[
    [ "Initialize", "class_particle_service.html#aa040f47e8bf58f9e7d989500efdb1c7d", null ],
    [ "Update", "class_particle_service.html#ab0a9171259d95336b2e604ff61a5afd0", null ],
    [ "Render", "class_particle_service.html#a9c46362faf747bbe6ed8c8f687862188", null ],
    [ "Emit", "class_particle_service.html#a42fcfa955292ea8f7855e0106a8f9a07", null ],
    [ "particle_pool_", "class_particle_service.html#a1e9671259f0593878e709112e0aa8203", null ],
    [ "active_indices_", "class_particle_service.html#aadad0340f8aec32e5c66d43f647a94b0", null ],
    [ "free_indices_", "class_particle_service.html#a767abde9dd55177357058b0fa8ff358d", null ],
    [ "pool_size_", "class_particle_service.html#a00181b3b0ec17a1d610856b1791acbcf", null ]
];