var class_i_destroyable =
[
    [ "IDestroyable", "class_i_destroyable.html#a7d19461c55d81362612742d55ab7646a", null ],
    [ "~IDestroyable", "class_i_destroyable.html#a35c9ffe4e1e2c443dcc10af52a5e0aa3", null ],
    [ "OnDestroy", "class_i_destroyable.html#a41cadeca15eceae1c675c3dd6bc9b828", null ],
    [ "IsPendingDestruction", "class_i_destroyable.html#ae1ed7646e09feeaa99cad381fb25ff1d", null ],
    [ "ReserveDestruction", "class_i_destroyable.html#a0e15c2754a5fb4acfc53a385111578b6", null ],
    [ "AddDestructionCallback", "class_i_destroyable.html#ae04246720b5cb6cf7407c1781a4f9e4a", null ],
    [ "pending_destruction_", "class_i_destroyable.html#af72b5e3fb92655470f2f6cfd538be0fe", null ],
    [ "destruction_callbacks_", "class_i_destroyable.html#a47dc3c93aa8c98cd2755017cef394204", null ]
];