var _debug_assistant_header_8h =
[
    [ "DweTextData", "struct_dwe_text_data.html", "struct_dwe_text_data" ],
    [ "DebugWindowElementType", "_debug_assistant_header_8h.html#a2fed9baa0f28e40affa5fec3b1073d36", [
      [ "Undefined", "_debug_assistant_header_8h.html#a2fed9baa0f28e40affa5fec3b1073d36aec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "Text", "_debug_assistant_header_8h.html#a2fed9baa0f28e40affa5fec3b1073d36a9dffbf69ffba8bc38bc4e01abf4b1675", null ],
      [ "CheckBox", "_debug_assistant_header_8h.html#a2fed9baa0f28e40affa5fec3b1073d36a7ea0f1332ade5b23b34502a3bfe715a2", null ],
      [ "Button", "_debug_assistant_header_8h.html#a2fed9baa0f28e40affa5fec3b1073d36a87b7760f14fbff78d8819291f36ab9a0", null ],
      [ "Graph", "_debug_assistant_header_8h.html#a2fed9baa0f28e40affa5fec3b1073d36a4cdbd2bafa8193091ba09509cedf94fd", null ]
    ] ]
];