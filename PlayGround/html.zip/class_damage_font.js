var class_damage_font =
[
    [ "DamageFont", "class_damage_font.html#ad121766a53d38bf8b0ae928664bcabdd", null ],
    [ "Update", "class_damage_font.html#a005472c6dcc47674597654a60501fc0b", null ],
    [ "Render", "class_damage_font.html#a5b874e90c948adfc67af2e42e5ceacbd", null ],
    [ "damage_text_", "class_damage_font.html#a22cbba2f5bbddb8fcd8488097aee9425", null ],
    [ "life_time_timer_", "class_damage_font.html#abfc22f89af8f7c5db424932624bd3296", null ],
    [ "initial_position_", "class_damage_font.html#ad53c9fa1866961f3ce48201a3fccfae9", null ]
];