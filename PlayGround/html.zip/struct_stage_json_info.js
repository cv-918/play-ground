var struct_stage_json_info =
[
    [ "id_", "struct_stage_json_info.html#aef41fed784be11454dcde1f5bc318555", null ],
    [ "spawn_pool_id_", "struct_stage_json_info.html#a686d24899c53a28ee676934168db6dcb", null ]
];