var _extern_8h =
[
    [ "g_hwnd", "_extern_8h.html#a803a83328c6891b81d6f47569ddc3ef0", null ],
    [ "g_dc", "_extern_8h.html#ac4bbb2905967f3da33c8cb3783fb6ec3", null ],
    [ "g_back_dc", "_extern_8h.html#a7a09cde7c3af54a0be04f53ee266c9f1", null ],
    [ "g_graphics", "_extern_8h.html#a85605808d68204bf7104c4acc96c1b3e", null ],
    [ "g_screen_size", "_extern_8h.html#a1e67772438fa0aaed7da2f0365462295", null ]
];