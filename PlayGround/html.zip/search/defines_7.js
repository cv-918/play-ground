var searchData=
[
  ['make_5finitialized_0',['MAKE_INITIALIZED',['../_interfaces_8h.html#af25ab2f37742e25c6f65b39f1f76d1e6',1,'Interfaces.h']]],
  ['max_5floadstring_1',['MAX_LOADSTRING',['../_entry_point_8cpp.html#a2b68559d692760680c326428841254d1',1,'EntryPoint.cpp']]]
];
