var searchData=
[
  ['violet_0',['Violet',['../namespace_palette.html#a2e9a90e2dfcd5f69eb306457c0e9a784',1,'Palette']]]
];
