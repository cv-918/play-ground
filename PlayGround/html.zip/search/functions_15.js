var searchData=
[
  ['yellow_0',['Yellow',['../namespace_palette.html#abe0138ba276ac1c238b055cdeaf92845',1,'Palette']]]
];
