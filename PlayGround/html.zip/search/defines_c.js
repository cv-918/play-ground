var searchData=
[
  ['win_5fcenter_5fx_0',['WIN_CENTER_X',['../_defines_8h.html#aba4b2ab537c321ab652a57772e56733b',1,'Defines.h']]],
  ['win_5fcenter_5fy_1',['WIN_CENTER_Y',['../_defines_8h.html#a5577aa4d8eeb5050054a37f2bae42363',1,'Defines.h']]],
  ['wincx_2',['WINCX',['../_defines_8h.html#acbf0378589572858aad69eace5595f88',1,'Defines.h']]],
  ['wincy_3',['WINCY',['../_defines_8h.html#a7aa50a914f1e3b1f7dd504b2bb9c3f7c',1,'Defines.h']]]
];
