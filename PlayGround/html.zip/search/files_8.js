var searchData=
[
  ['jsondatamanager_2ecpp_0',['JsonDataManager.cpp',['../_json_data_manager_8cpp.html',1,'']]],
  ['jsondatamanager_2eh_1',['JsonDataManager.h',['../_json_data_manager_8h.html',1,'']]]
];
