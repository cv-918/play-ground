var indexSectionsWithContent =
{
  0: "_abcdefghijklmnoprstuvwxyz~",
  1: "_abcdeghijklmnoprstuw",
  2: "cdmpu",
  3: "abcdeghijlmnoprstuvw",
  4: "_abcdefghilmnoprstuvwyz~",
  5: "abcdefghiklmnoprstuvwxyz",
  6: "_j",
  7: "_abcdehikmnopsu",
  8: "abcdefghiklmnoprstuw",
  9: "_cdegikmprsuw",
  10: "st"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines",
  10: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Macros",
  10: "Modules"
};

