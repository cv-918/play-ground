var searchData=
[
  ['magenta_0',['Magenta',['../namespace_palette.html#a7b9e23ec716f18cbce2e02b59722560e',1,'Palette']]],
  ['magnitude_1',['Magnitude',['../struct___vector2.html#a975d2b78637a54dfa496727940813b08',1,'_Vector2::Magnitude()'],['../struct___vector3.html#a6b2b30c778063615f93316c6d1c4cb0f',1,'_Vector3::Magnitude()']]],
  ['markasdead_2',['MarkAsDead',['../class_status.html#a759f7f917bfcd8f68d101acae1264620',1,'Status']]],
  ['markasplayerdied_3',['MarkAsPlayerDied',['../class_run_state.html#aeca6129b183d55d072958eab1111f3e2',1,'RunState']]],
  ['markcanprogressnextstage_4',['MarkCanProgressNextStage',['../class_stage_manager.html#a9211b83c7ad55db6ec90735e9121d0a1',1,'StageManager']]],
  ['maroon_5',['Maroon',['../namespace_palette.html#aa0066fd1178c6ff1a9a0f3360032c8fe',1,'Palette']]],
  ['measure_6',['Measure',['../class_debug_window_element.html#ac7d2cd55468777cda686e74e59a52d41',1,'DebugWindowElement::Measure()'],['../class_d_w_e___button.html#a40eb46d27bfded3b00a8a0a93e390d14',1,'DWE_Button::Measure()'],['../class_d_w_e___check_box.html#a085774d79d75d84c3bc85f47da7d920d',1,'DWE_CheckBox::Measure()'],['../class_d_w_e___text.html#adf257d52b9eec1067045202b65cd0ebd',1,'DWE_Text::Measure()']]],
  ['measurestring_7',['MeasureString',['../namespace_draw_functions.html#a38204181042273109652ed3aafb3b9d0',1,'DrawFunctions::MeasureString(const std::wstring &amp;_text, _float _font_size=12.f, _int _style_bitmask=Gdiplus::FontStyleRegular)'],['../namespace_draw_functions.html#a4e73cc6ed1c84902006c77dafc733fea',1,'DrawFunctions::MeasureString(const std::wstring &amp;_text, _float _font_size, _int _style_bitmask, _float _max_width, _bool _is_no_wrap)']]],
  ['mint_8',['Mint',['../namespace_palette.html#aaefb6c9165271d62f289a8d5452df7e2',1,'Palette']]],
  ['mossgreen_9',['MossGreen',['../namespace_palette.html#a3e542fbdaab778af5efecfaa49b96ab2',1,'Palette']]],
  ['mousedelta_10',['MouseDelta',['../class_input_manager.html#ab3d65e756ec295c8d5ea0e7ab665e81e',1,'InputManager']]],
  ['mousepoint_11',['MousePoint',['../class_input_manager.html#a8e2473ed4926e3d360601fe2b61ad09f',1,'InputManager']]],
  ['movecenterto_12',['MoveCenterTo',['../struct___rect.html#a31c73f7fc962e0dd75fbce8371021350',1,'_Rect']]],
  ['moveltto_13',['MoveLtTo',['../struct___rect.html#ad4c7fff653568baac9476b1050a5d697',1,'_Rect']]],
  ['movement_14',['Movement',['../class_movement.html#ae0493997549e8b3ead5146bea074010d',1,'Movement']]],
  ['movex_15',['MoveX',['../struct___rect.html#acf5dd9b65b5cf8c2b754ad4eec1a6b84',1,'_Rect::MoveX()'],['../class_u_i_base.html#a737d937536560694dde0475284231989',1,'UIBase::MoveX()'],['../class_widget_base.html#a4406c9daa318e5a75f8abbd1dd6664ad',1,'WidgetBase::MoveX()']]],
  ['movey_16',['MoveY',['../struct___rect.html#a08668ae2f2b4eeec6aaf926812089553',1,'_Rect::MoveY()'],['../class_u_i_base.html#aefd40945ab2c90921f6983ea703b048c',1,'UIBase::MoveY()'],['../class_widget_base.html#a242ecada84b021a65d5df5a7a80f72f5',1,'WidgetBase::MoveY()']]],
  ['myregisterclass_17',['MyRegisterClass',['../_entry_point_8cpp.html#aa0d0c9beb94350f8eac8fc4026a65375',1,'EntryPoint.cpp']]]
];
