var searchData=
[
  ['palette_0',['Palette',['../namespace_palette.html',1,'']]],
  ['path_1',['Path',['../namespace_path.html',1,'']]]
];
