var searchData=
[
  ['widgetbase_0',['WidgetBase',['../class_widget_base.html',1,'']]]
];
