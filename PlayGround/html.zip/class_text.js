var class_text =
[
    [ "Text", "class_text.html#ab3e26143fccc52699bcc5149cae852bc", null ],
    [ "Render", "class_text.html#a5828aca5744fcb19338742bd8471fe12", null ],
    [ "SetText", "class_text.html#a1aceeb3d23f74160d33e492ed94ff28e", null ],
    [ "SetColor", "class_text.html#ab9c38f2cef6bd2e2974ef1b2501d3d66", null ],
    [ "SetFontSize", "class_text.html#a0e2bd41017345b76efcb061d5e6c10d7", null ],
    [ "SetAlpha", "class_text.html#af75f53d48db7be014d64dc6ccf9bd895", null ],
    [ "text_", "class_text.html#adb3994231916b7aa909a9d18543c75e0", null ],
    [ "color_", "class_text.html#aeb4d0561366c4903e12b89fac2e5c3a0", null ],
    [ "font_size_", "class_text.html#ad847415eef5f000a82ac611db49070c4", null ],
    [ "is_center_", "class_text.html#a684958b78a75f5cebe14957c954cc597", null ]
];