var class_json_data_manager =
[
    [ "~JsonDataManager", "class_json_data_manager.html#ac265136ff21b3975be57942b4cd489f0", null ],
    [ "Load", "class_json_data_manager.html#a879eefb5eb0571841f498a224a261a44", null ],
    [ "Save", "class_json_data_manager.html#a4397163d38be11198e277d3f1acf0a12", null ],
    [ "GetTable", "class_json_data_manager.html#a29e86fb96a06111ae783251c89be4349", null ],
    [ "GetDataCount", "class_json_data_manager.html#ae5aad89399087ca23b9892547e8062a9", null ],
    [ "GetData", "class_json_data_manager.html#a0bdaa2b79f0248f3b6430bb843bbf2cd", null ],
    [ "GetDataByIndex", "class_json_data_manager.html#a2b028faca0db7ce565d51a8f6e74d255", null ],
    [ "data_table_", "class_json_data_manager.html#ab0f714dc421c21457d6ee0973d31aba9", null ]
];