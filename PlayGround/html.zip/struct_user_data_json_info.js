var struct_user_data_json_info =
[
    [ "id_", "struct_user_data_json_info.html#a11c27e040f17f790ed7a014c19df1afa", null ],
    [ "dust_count_", "struct_user_data_json_info.html#a6d1dd746527992453c8f67a910f3c537", null ],
    [ "experience_", "struct_user_data_json_info.html#a402464f9a10b58023d17d7d0acadd5a5", null ],
    [ "unlocked_character_ids_", "struct_user_data_json_info.html#ac30d7780d37daa01832743b30adbc364", null ],
    [ "acquired_node_ids_", "struct_user_data_json_info.html#a5c3c22435cde46d3049d9253a1a83799", null ],
    [ "stage_progress_", "struct_user_data_json_info.html#a94a8e043d89d5b522ea987cc3c778411", null ]
];