var _common_game_play_type_8h =
[
    [ "UnitJsonInfo", "struct_unit_json_info.html", "struct_unit_json_info" ],
    [ "EnemyJsonInfo", "struct_enemy_json_info.html", "struct_enemy_json_info" ],
    [ "PlayableCharacterJsonInfo", "struct_playable_character_json_info.html", "struct_playable_character_json_info" ],
    [ "UnitCreationInfo", "struct_unit_creation_info.html", "struct_unit_creation_info" ],
    [ "RunSessionResult", "struct_run_session_result.html", "struct_run_session_result" ],
    [ "StageJsonInfo", "struct_stage_json_info.html", "struct_stage_json_info" ],
    [ "SpawnEnemyJsonInfo", "struct_spawn_enemy_json_info.html", "struct_spawn_enemy_json_info" ],
    [ "StageSpawnPoolJsonInfo", "struct_stage_spawn_pool_json_info.html", "struct_stage_spawn_pool_json_info" ],
    [ "AttributeNodeJsonInfo", "struct_attribute_node_json_info.html", "struct_attribute_node_json_info" ],
    [ "Stat", "struct_stat.html", "struct_stat" ],
    [ "AttributeStat", "struct_attribute_stat.html", "struct_attribute_stat" ],
    [ "SkillJsonInfo", "struct_skill_json_info.html", "struct_skill_json_info" ],
    [ "UserDataJsonInfo", "struct_user_data_json_info.html", "struct_user_data_json_info" ],
    [ "CollisionLayer", "_common_game_play_type_8h.html#a8e00d7b68952c9891c104ecf503b61b8", [
      [ "PlayerBody", "_common_game_play_type_8h.html#a8e00d7b68952c9891c104ecf503b61b8a7f69c2297e42c7676be88bfc3e67c016", null ],
      [ "PlayerAttack", "_common_game_play_type_8h.html#a8e00d7b68952c9891c104ecf503b61b8a591ff635fd539aade6fb6f6c018d2cfa", null ],
      [ "PlayerCollector", "_common_game_play_type_8h.html#a8e00d7b68952c9891c104ecf503b61b8a8fd63325e333f5be2ebe893df69d2c63", null ],
      [ "EnemyBody", "_common_game_play_type_8h.html#a8e00d7b68952c9891c104ecf503b61b8a40f692fb44fbb594aeb0d2d278ad1837", null ],
      [ "EnemyAttack", "_common_game_play_type_8h.html#a8e00d7b68952c9891c104ecf503b61b8a66f6feb7d19725d2399ed072fc9648e0", null ],
      [ "EnemyBullet", "_common_game_play_type_8h.html#a8e00d7b68952c9891c104ecf503b61b8a87da8c547ceb34e5da159875a8960231", null ],
      [ "PropsBody", "_common_game_play_type_8h.html#a8e00d7b68952c9891c104ecf503b61b8a22443943a61a75591bfef3c954bdbac5", null ],
      [ "End", "_common_game_play_type_8h.html#a8e00d7b68952c9891c104ecf503b61b8a87557f11575c0ad78e4e28abedc13b6e", null ]
    ] ],
    [ "SceneType", "_common_game_play_type_8h.html#a006282dc9ad93696316e776700c3c948", [
      [ "Intro", "_common_game_play_type_8h.html#a006282dc9ad93696316e776700c3c948a1cad35d4b3b9f624f82dbf237daaf188", null ],
      [ "Loading", "_common_game_play_type_8h.html#a006282dc9ad93696316e776700c3c948a16bfbf9c462762cf1cba4134ec53c504", null ],
      [ "OutGame", "_common_game_play_type_8h.html#a006282dc9ad93696316e776700c3c948a37121b60c5f184fbc7c324f7fcec1418", null ],
      [ "InGame", "_common_game_play_type_8h.html#a006282dc9ad93696316e776700c3c948a7f3d370e94c8b1fea09838572013d8ec", null ],
      [ "Count", "_common_game_play_type_8h.html#a006282dc9ad93696316e776700c3c948ae93f994f01c537c4e2f7d8528c3eb5e9", null ]
    ] ],
    [ "StageState", "_common_game_play_type_8h.html#abc717cf4240a31715d3cdfee8ef42642", [
      [ "Undefined", "_common_game_play_type_8h.html#abc717cf4240a31715d3cdfee8ef42642aec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "Enter", "_common_game_play_type_8h.html#abc717cf4240a31715d3cdfee8ef42642af1851d5600eae616ee802a31ac74701b", null ],
      [ "Ready", "_common_game_play_type_8h.html#abc717cf4240a31715d3cdfee8ef42642ae7d31fc0602fb2ede144d18cdffd816b", null ],
      [ "Play", "_common_game_play_type_8h.html#abc717cf4240a31715d3cdfee8ef42642ade3c731be5633838089a07179d301d7b", null ],
      [ "Pause", "_common_game_play_type_8h.html#abc717cf4240a31715d3cdfee8ef42642a105b296a83f9c105355403f3332af50f", null ],
      [ "Clear", "_common_game_play_type_8h.html#abc717cf4240a31715d3cdfee8ef42642adc30bc0c7914db5918da4263fce93ad2", null ],
      [ "Result", "_common_game_play_type_8h.html#abc717cf4240a31715d3cdfee8ef42642a8eea62084ca7e541d918e823422bd82e", null ],
      [ "Exit", "_common_game_play_type_8h.html#abc717cf4240a31715d3cdfee8ef42642afef46e5063ce3dc78b8ae64fa474241d", null ]
    ] ],
    [ "ComponentType", "_common_game_play_type_8h.html#a81f78fc173dedefe5a049c0aa3eed2c0", [
      [ "Undefined", "_common_game_play_type_8h.html#a81f78fc173dedefe5a049c0aa3eed2c0aec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "Transform", "_common_game_play_type_8h.html#a81f78fc173dedefe5a049c0aa3eed2c0a2ff4148554480a37f85efd299df04850", null ],
      [ "Status", "_common_game_play_type_8h.html#a81f78fc173dedefe5a049c0aa3eed2c0aec53a8c4f07baed5d8825072c89799be", null ],
      [ "Movement", "_common_game_play_type_8h.html#a81f78fc173dedefe5a049c0aa3eed2c0a4642e767f9251fa40afadbc963f80b7a", null ],
      [ "SphereCollider", "_common_game_play_type_8h.html#a81f78fc173dedefe5a049c0aa3eed2c0a66c4e352bd7b31d256989dac594dd3af", null ],
      [ "RectCollider", "_common_game_play_type_8h.html#a81f78fc173dedefe5a049c0aa3eed2c0a5bdd69b4b1134675b691a7edad0c112e", null ],
      [ "EllipseCollider", "_common_game_play_type_8h.html#a81f78fc173dedefe5a049c0aa3eed2c0a4360fca93bf62a5bf88e1b287434b35e", null ],
      [ "Combat", "_common_game_play_type_8h.html#a81f78fc173dedefe5a049c0aa3eed2c0a30ad1054cf7ad7636a26844a6f782e1f", null ]
    ] ],
    [ "MovementPattern", "_common_game_play_type_8h.html#a186277541647215e16e20759249bbe67", [
      [ "Undefined", "_common_game_play_type_8h.html#a186277541647215e16e20759249bbe67aec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "Playable", "_common_game_play_type_8h.html#a186277541647215e16e20759249bbe67af29742716e62973a5377253fde59dba3", null ],
      [ "Stopped", "_common_game_play_type_8h.html#a186277541647215e16e20759249bbe67ac23e2b09ebe6bf4cb5e2a9abe85c0be2", null ],
      [ "Directional", "_common_game_play_type_8h.html#a186277541647215e16e20759249bbe67ab04a8341537fac392bfd17776491d03c", null ],
      [ "Target", "_common_game_play_type_8h.html#a186277541647215e16e20759249bbe67ac41a31890959544c6523af684561abe5", null ],
      [ "Count", "_common_game_play_type_8h.html#a186277541647215e16e20759249bbe67ae93f994f01c537c4e2f7d8528c3eb5e9", null ]
    ] ],
    [ "EnemyCategory", "_common_game_play_type_8h.html#a6aca36f0daad31db1d2a96be5c8a9829", [
      [ "Undefined", "_common_game_play_type_8h.html#a6aca36f0daad31db1d2a96be5c8a9829aec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "WasExpDust", "_common_game_play_type_8h.html#a6aca36f0daad31db1d2a96be5c8a9829a696ba10ce25b6ed11bf58f6ac6b0e525", null ],
      [ "Count", "_common_game_play_type_8h.html#a6aca36f0daad31db1d2a96be5c8a9829ae93f994f01c537c4e2f7d8528c3eb5e9", null ]
    ] ],
    [ "EnemyTier", "_common_game_play_type_8h.html#a9c78e916ddf4d3efd2dfbfb407fc04f0", [
      [ "Undefined", "_common_game_play_type_8h.html#a9c78e916ddf4d3efd2dfbfb407fc04f0aec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "Normal", "_common_game_play_type_8h.html#a9c78e916ddf4d3efd2dfbfb407fc04f0a960b44c579bc2f6818d2daaf9e4c16f0", null ],
      [ "Elite", "_common_game_play_type_8h.html#a9c78e916ddf4d3efd2dfbfb407fc04f0ab13082ea3fe2642f1fd1fb76de03058b", null ],
      [ "Danger", "_common_game_play_type_8h.html#a9c78e916ddf4d3efd2dfbfb407fc04f0a990816b607ebf99b1415760965e4d564", null ],
      [ "Special", "_common_game_play_type_8h.html#a9c78e916ddf4d3efd2dfbfb407fc04f0ab4c2b550635fe54fd29f2b64dfaca55d", null ],
      [ "Count", "_common_game_play_type_8h.html#a9c78e916ddf4d3efd2dfbfb407fc04f0ae93f994f01c537c4e2f7d8528c3eb5e9", null ]
    ] ],
    [ "EnemySpecialRole", "_common_game_play_type_8h.html#a379b9cdef9249279482593230b92585e", [
      [ "Undefined", "_common_game_play_type_8h.html#a379b9cdef9249279482593230b92585eaec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "Tank", "_common_game_play_type_8h.html#a379b9cdef9249279482593230b92585eae4419464d570c4b497ba1979e790b104", null ],
      [ "Rich", "_common_game_play_type_8h.html#a379b9cdef9249279482593230b92585ea84814b43bd0271bd407e14ca38654207", null ],
      [ "Shooter", "_common_game_play_type_8h.html#a379b9cdef9249279482593230b92585ea07312fb380dc0e653b77ddc9dfa05013", null ],
      [ "Splitter", "_common_game_play_type_8h.html#a379b9cdef9249279482593230b92585ea41cb9b797ebc6f6f6314e3ded935f4cf", null ],
      [ "Count", "_common_game_play_type_8h.html#a379b9cdef9249279482593230b92585eae93f994f01c537c4e2f7d8528c3eb5e9", null ]
    ] ],
    [ "ProjectilePattern", "_common_game_play_type_8h.html#a84bf680062953ab4516fed6e14792e5e", [
      [ "Undefined", "_common_game_play_type_8h.html#a84bf680062953ab4516fed6e14792e5eaec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "Direct", "_common_game_play_type_8h.html#a84bf680062953ab4516fed6e14792e5eafd1dd0c603be8170f9eae0be9f2f6afb", null ],
      [ "Aimed", "_common_game_play_type_8h.html#a84bf680062953ab4516fed6e14792e5ea9ea85700b7f1743c64bc83e7c34b1a79", null ],
      [ "Count", "_common_game_play_type_8h.html#a84bf680062953ab4516fed6e14792e5eae93f994f01c537c4e2f7d8528c3eb5e9", null ]
    ] ],
    [ "PlayableCharacterId", "_common_game_play_type_8h.html#ae58245deebe306876c344dba085fdd20", [
      [ "Undefined", "_common_game_play_type_8h.html#ae58245deebe306876c344dba085fdd20aec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "Dusty", "_common_game_play_type_8h.html#ae58245deebe306876c344dba085fdd20a7bb33d6141f427f4f19b019f5eb7905b", null ]
    ] ],
    [ "PropsType", "_common_game_play_type_8h.html#a02bf52acb5b75f5f8211ff7d4f8075da", [
      [ "Undefined", "_common_game_play_type_8h.html#a02bf52acb5b75f5f8211ff7d4f8075daaec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "Dust", "_common_game_play_type_8h.html#a02bf52acb5b75f5f8211ff7d4f8075daade3493ea6e7cb1529c9922e9e501faf8", null ]
    ] ],
    [ "PropsState", "_common_game_play_type_8h.html#a0bc6786b1f48cd9c6f999c261d1f0f42", [
      [ "Undefined", "_common_game_play_type_8h.html#a0bc6786b1f48cd9c6f999c261d1f0f42aec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "Idle", "_common_game_play_type_8h.html#a0bc6786b1f48cd9c6f999c261d1f0f42ae599161956d626eda4cb0a5ffb85271c", null ],
      [ "Tracking", "_common_game_play_type_8h.html#a0bc6786b1f48cd9c6f999c261d1f0f42a2205dc082ba550b67ad71e3e2241d9a6", null ]
    ] ],
    [ "NodeGrade", "_common_game_play_type_8h.html#a2ea511e7c37deda8b4a6bfa7ab33034b", [
      [ "Undefined", "_common_game_play_type_8h.html#a2ea511e7c37deda8b4a6bfa7ab33034baec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "Common", "_common_game_play_type_8h.html#a2ea511e7c37deda8b4a6bfa7ab33034bad13bc5b68b2bd9e18f29777db17cc563", null ],
      [ "Major", "_common_game_play_type_8h.html#a2ea511e7c37deda8b4a6bfa7ab33034ba3b329734e45b57e60f3df64c2cf412a9", null ],
      [ "Keystone", "_common_game_play_type_8h.html#a2ea511e7c37deda8b4a6bfa7ab33034ba1ce2096c300f78bbb8389ca2603e6dd9", null ]
    ] ],
    [ "NodeTier", "_common_game_play_type_8h.html#a98bb98a73d6380988e6a7a91b87bfe3d", [
      [ "Undefined", "_common_game_play_type_8h.html#a98bb98a73d6380988e6a7a91b87bfe3daec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "Tier1", "_common_game_play_type_8h.html#a98bb98a73d6380988e6a7a91b87bfe3da0fdf99ebbdcd0198744caa9b8c5c6ca4", null ],
      [ "Tier2", "_common_game_play_type_8h.html#a98bb98a73d6380988e6a7a91b87bfe3dad167d667548ae1364f67b9ce0b6918a5", null ],
      [ "Tier3", "_common_game_play_type_8h.html#a98bb98a73d6380988e6a7a91b87bfe3da1fee01fe8bbe05778f82f32df56b0061", null ]
    ] ],
    [ "NodeState", "_common_game_play_type_8h.html#a55999f3c61e69a9b5d871dcf480a8c5e", [
      [ "Undefined", "_common_game_play_type_8h.html#a55999f3c61e69a9b5d871dcf480a8c5eaec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "Hidden", "_common_game_play_type_8h.html#a55999f3c61e69a9b5d871dcf480a8c5ea7acdf85c69cc3c5305456a293524386e", null ],
      [ "Locked", "_common_game_play_type_8h.html#a55999f3c61e69a9b5d871dcf480a8c5ead0f2e5376298c880665077b565ffd7dd", null ],
      [ "Unlocked", "_common_game_play_type_8h.html#a55999f3c61e69a9b5d871dcf480a8c5eac76fd517e45cc95709f4ac106efa4a94", null ],
      [ "Acquired", "_common_game_play_type_8h.html#a55999f3c61e69a9b5d871dcf480a8c5ea0a5548963c077fd0eb9cae94270939f2", null ],
      [ "Mastered", "_common_game_play_type_8h.html#a55999f3c61e69a9b5d871dcf480a8c5eafbfbbdd38d356af8d0239cff7e9d9c1f", null ]
    ] ],
    [ "AttributeType", "_common_game_play_type_8h.html#a349a9cde14be8097df865ba0469c0ab2", [
      [ "Undefined", "_common_game_play_type_8h.html#a349a9cde14be8097df865ba0469c0ab2aec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "SpecialAbility", "_common_game_play_type_8h.html#a349a9cde14be8097df865ba0469c0ab2acef30a72e563e255a7148318592cd096", null ],
      [ "Attack", "_common_game_play_type_8h.html#a349a9cde14be8097df865ba0469c0ab2adcfafcb4323b102c7e204555d313ba0a", null ],
      [ "Hp", "_common_game_play_type_8h.html#a349a9cde14be8097df865ba0469c0ab2acc1792ec657aa21f33554a2024aaff50", null ],
      [ "MoveSpeed", "_common_game_play_type_8h.html#a349a9cde14be8097df865ba0469c0ab2a3dfb8a09b650ce66270c54fdf5c2aa74", null ],
      [ "AttackRange", "_common_game_play_type_8h.html#a349a9cde14be8097df865ba0469c0ab2ab368d16134fba69bdd208d3d0c7c7c5b", null ],
      [ "CollectionRange", "_common_game_play_type_8h.html#a349a9cde14be8097df865ba0469c0ab2a6ebf5d6624f0e102ceb58081f4f7a908", null ],
      [ "Runtime", "_common_game_play_type_8h.html#a349a9cde14be8097df865ba0469c0ab2abc366f2d0ba3d681e7a3899917c5d3de", null ]
    ] ],
    [ "SpecialAbilityId", "_common_game_play_type_8h.html#a678b707159d79b3776a51a06a4c33ba5", [
      [ "Undefined", "_common_game_play_type_8h.html#a678b707159d79b3776a51a06a4c33ba5aec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "DustCollect", "_common_game_play_type_8h.html#a678b707159d79b3776a51a06a4c33ba5a02cedb21529f79ed172f57c650735857", null ]
    ] ],
    [ "AttributeCalculationType", "_common_game_play_type_8h.html#afcbbdcac814a0b316fd54be2b785d8a1", [
      [ "Undefined", "_common_game_play_type_8h.html#afcbbdcac814a0b316fd54be2b785d8a1aec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "Additive", "_common_game_play_type_8h.html#afcbbdcac814a0b316fd54be2b785d8a1a3f7b3d8ee7bf0d542bd50821c083888f", null ],
      [ "Multiplicative", "_common_game_play_type_8h.html#afcbbdcac814a0b316fd54be2b785d8a1a0d73bf5decac382ed6a8adc3838fd7e2", null ]
    ] ],
    [ "NodeDirection", "_common_game_play_type_8h.html#a3011b28ee66a2d3f8320765ba5e513d1", [
      [ "Undefined", "_common_game_play_type_8h.html#a3011b28ee66a2d3f8320765ba5e513d1aec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "Up", "_common_game_play_type_8h.html#a3011b28ee66a2d3f8320765ba5e513d1a258f49887ef8d14ac268c92b02503aaa", null ],
      [ "RightUp", "_common_game_play_type_8h.html#a3011b28ee66a2d3f8320765ba5e513d1a41f885e8adf5274339a2cad184e99912", null ],
      [ "Right", "_common_game_play_type_8h.html#a3011b28ee66a2d3f8320765ba5e513d1a92b09c7c48c520c3c55e497875da437c", null ],
      [ "RightDown", "_common_game_play_type_8h.html#a3011b28ee66a2d3f8320765ba5e513d1ac7ff24224bc4b699e06c58a663ac618c", null ],
      [ "Down", "_common_game_play_type_8h.html#a3011b28ee66a2d3f8320765ba5e513d1a08a38277b0309070706f6652eeae9a53", null ],
      [ "LeftDown", "_common_game_play_type_8h.html#a3011b28ee66a2d3f8320765ba5e513d1ac0301e45191901ce8040ef1c1695f832", null ],
      [ "Left", "_common_game_play_type_8h.html#a3011b28ee66a2d3f8320765ba5e513d1a945d5e233cf7d6240f6b783b36a374ff", null ],
      [ "LeftUp", "_common_game_play_type_8h.html#a3011b28ee66a2d3f8320765ba5e513d1a105736deb2f54f03c011e5f053e08d00", null ]
    ] ],
    [ "SkillType", "_common_game_play_type_8h.html#af4541d30ebbff76b1f9f689519789234", [
      [ "Undefined", "_common_game_play_type_8h.html#af4541d30ebbff76b1f9f689519789234aec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "Active", "_common_game_play_type_8h.html#af4541d30ebbff76b1f9f689519789234a4d3d769b812b6faa6b76e1a8abaece2d", null ],
      [ "Deployable", "_common_game_play_type_8h.html#af4541d30ebbff76b1f9f689519789234a6ccf03a957f7b96c54f6c78e10a54c36", null ],
      [ "Summon", "_common_game_play_type_8h.html#af4541d30ebbff76b1f9f689519789234aefde9837421a1454da9ca1d72146c552", null ],
      [ "Count", "_common_game_play_type_8h.html#af4541d30ebbff76b1f9f689519789234ae93f994f01c537c4e2f7d8528c3eb5e9", null ]
    ] ],
    [ "SkillUnlockType", "_common_game_play_type_8h.html#a42ec85bee0e7dd04f9cfed755084690f", [
      [ "Undefined", "_common_game_play_type_8h.html#a42ec85bee0e7dd04f9cfed755084690faec0fc0100c4fc1ce4eea230c3dc10360", null ],
      [ "NodeUnlock", "_common_game_play_type_8h.html#a42ec85bee0e7dd04f9cfed755084690fae341b84665e5ebf50678168d08e4a762", null ],
      [ "StageClear", "_common_game_play_type_8h.html#a42ec85bee0e7dd04f9cfed755084690faa998c65e91da9d06b8db92859d13c546", null ],
      [ "ResourceAmount", "_common_game_play_type_8h.html#a42ec85bee0e7dd04f9cfed755084690fabfe50ccc36675d4008f4b7baf1331706", null ],
      [ "TimeElapsed", "_common_game_play_type_8h.html#a42ec85bee0e7dd04f9cfed755084690fabf99cf7e56562e0125e9a648597239f8", null ]
    ] ],
    [ "__DebugColliderRenderState", "_common_game_play_type_8h.html#af13306f464d61aef8bb071f15532319f", [
      [ "OnDisabled", "_common_game_play_type_8h.html#af13306f464d61aef8bb071f15532319faaf0915209d99e40d5a08e26674753a17", null ],
      [ "OnNormal", "_common_game_play_type_8h.html#af13306f464d61aef8bb071f15532319faa173d20b3651649f1fd45417acbe2236", null ],
      [ "OnCollision", "_common_game_play_type_8h.html#af13306f464d61aef8bb071f15532319fac0daaf44372fad26e40d1b097e01106d", null ],
      [ "Count", "_common_game_play_type_8h.html#af13306f464d61aef8bb071f15532319fae93f994f01c537c4e2f7d8528c3eb5e9", null ]
    ] ]
];