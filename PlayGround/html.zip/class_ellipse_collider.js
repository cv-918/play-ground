var class_ellipse_collider =
[
    [ "EllipseCollider", "class_ellipse_collider.html#ab8c80ba967c1215a3577f2f1d05169f9", null ],
    [ "EllipseCollider", "class_ellipse_collider.html#aafc2589fc52840e89aee1a72cd6718b6", null ],
    [ "LateUpdate", "class_ellipse_collider.html#a03f79b2b677b7bbc107005047f0b99b7", null ],
    [ "Render", "class_ellipse_collider.html#a55d6d10de2c55ddbd3c39dfad628148f", null ],
    [ "CheckCollided", "class_ellipse_collider.html#a30c17b4f64169f6ccb8fe6d6c2db788b", null ],
    [ "SetRadius", "class_ellipse_collider.html#a584b07d97f681c36659b0bd156ba1814", null ],
    [ "GetCenter", "class_ellipse_collider.html#ac9c5d07171a45b5aeb5d2940941db09a", null ],
    [ "GetRadiusX", "class_ellipse_collider.html#af8bf9906825f6c64e48069ac642e2f35", null ],
    [ "GetYRatio", "class_ellipse_collider.html#a720c388ae4b3e29a2f701f591bc2a3bf", null ],
    [ "radius_x_", "class_ellipse_collider.html#a14bc7b82bc437912faeff878360cf0cc", null ],
    [ "radius_y_", "class_ellipse_collider.html#a359aaa16a52eb63e83abfb6d9f548b91", null ],
    [ "y_ratio_", "class_ellipse_collider.html#a34c15bc85f071e5cc4a60647531b1ce4", null ],
    [ "center_", "class_ellipse_collider.html#ad7aae3e75b808105a8fdbecfa9000713", null ]
];