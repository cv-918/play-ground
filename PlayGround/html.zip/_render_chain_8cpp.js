var _render_chain_8cpp =
[
    [ "g_hwnd", "_render_chain_8cpp.html#a803a83328c6891b81d6f47569ddc3ef0", null ],
    [ "g_dc", "_render_chain_8cpp.html#ac4bbb2905967f3da33c8cb3783fb6ec3", null ],
    [ "g_back_dc", "_render_chain_8cpp.html#a7a09cde7c3af54a0be04f53ee266c9f1", null ],
    [ "g_graphics", "_render_chain_8cpp.html#a85605808d68204bf7104c4acc96c1b3e", null ],
    [ "g_screen_size", "_render_chain_8cpp.html#a1e67772438fa0aaed7da2f0365462295", null ]
];