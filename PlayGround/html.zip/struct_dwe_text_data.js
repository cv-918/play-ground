var struct_dwe_text_data =
[
    [ "DweTextData", "struct_dwe_text_data.html#ad9c5189ab4f8c71fde406d6da03facfc", null ],
    [ "DweTextData", "struct_dwe_text_data.html#a60ccb1a03db878604a43a9ab09c63bd4", null ],
    [ "text_", "struct_dwe_text_data.html#a88528cc3dc859c345890fd719a6c0865", null ],
    [ "color_", "struct_dwe_text_data.html#a9f62f129ddd8a098bdfe4a49f25fb7db", null ],
    [ "font_size_", "struct_dwe_text_data.html#ace14302854da8525b3fc2bec43287947", null ],
    [ "style_bitmask_", "struct_dwe_text_data.html#a9f5a6738469df5a6cb086572642fe693", null ],
    [ "alignment_horizontal_", "struct_dwe_text_data.html#a1ac8d5709873fc99e4c8017e4bbc9ef4", null ],
    [ "alignment_vertical_", "struct_dwe_text_data.html#a4d421595b92910229efea19cfdfaf237", null ]
];