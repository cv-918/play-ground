var struct_particle =
[
    [ "position_", "struct_particle.html#a7ecb1e05af0c57a3b9a6d35a69ddc301", null ],
    [ "velocity_", "struct_particle.html#a39bac5efcbc6a6ee37b812b4d093a5ea", null ],
    [ "life_time_", "struct_particle.html#a893baae01a955a8b34a67813e3114d5c", null ],
    [ "max_life_time_", "struct_particle.html#a20794949dc6ca72552242b089cf44bf2", null ],
    [ "is_active_", "struct_particle.html#a0476982e0c23e3ba8ec2a3fb1e433201", null ],
    [ "currentScale", "struct_particle.html#abb9db991b68ed768acd2708c54dc251a", null ],
    [ "currentColor", "struct_particle.html#a0b2b87cfdda3740cff36e1dfb9a75665", null ],
    [ "setting_", "struct_particle.html#a5b7fc354720adfed1541b812e114bf08", null ]
];