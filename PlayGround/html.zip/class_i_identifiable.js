var class_i_identifiable =
[
    [ "IIdentifiable", "class_i_identifiable.html#a5821936c7a68b0a13657905d378a0a52", null ],
    [ "~IIdentifiable", "class_i_identifiable.html#a3a9903afe06b30e0c479311a87e86c5e", null ],
    [ "ID", "class_i_identifiable.html#a6d5503aff23666e249e179e572171153", null ],
    [ "ID", "class_i_identifiable.html#a8f4338d4ef037e54415e65d68f0f4dc4", null ],
    [ "Name", "class_i_identifiable.html#a8f0cd27b2b2838bdcc0252bd888e499f", null ],
    [ "Name", "class_i_identifiable.html#acb52350947e5a82fe1084de9012c6a26", null ],
    [ "_SetNumberingName", "class_i_identifiable.html#a6867d54bde78f93202974b0954c0e073", null ],
    [ "id_", "class_i_identifiable.html#a550ce0736bc15533fbba5d208bc705c5", null ],
    [ "name_", "class_i_identifiable.html#af870361f376a28ceecccd2d77bf3e902", null ]
];