var class_i_singleton =
[
    [ "Get", "class_i_singleton.html#a70571aebaec12e065e2e085b7fe04f22", null ]
];