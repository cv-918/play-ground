var class_game_state =
[
    [ "GetPause", "class_game_state.html#a63c5fe2df9056abff8d9b794d4005b11", null ],
    [ "SetPause", "class_game_state.html#a071e71c75183154af67de34cf28ad2bf", null ],
    [ "pause_", "class_game_state.html#aca22db7faf21cd26b456b506f5d7785d", null ],
    [ "debug_mode_", "class_game_state.html#ab7c981ee9a74a6730d8aba424d078138", null ]
];