var struct_input_manager_1_1_key_state =
[
    [ "is_down", "struct_input_manager_1_1_key_state.html#ad376d97c592f5822e68d4b0217169d99", null ],
    [ "went_down", "struct_input_manager_1_1_key_state.html#af82f310522c0793f179fa5038020cdc7", null ],
    [ "went_up", "struct_input_manager_1_1_key_state.html#a58f5bd16975544f45bd8a684693ad278", null ]
];