var dir_667667b93a0e36996bcf56d30dd75b18 =
[
    [ "JsonDataManager.cpp", "_json_data_manager_8cpp.html", null ],
    [ "JsonDataManager.h", "_json_data_manager_8h.html", "_json_data_manager_8h" ]
];