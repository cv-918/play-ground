var class_object_manager =
[
    [ "~ObjectManager", "class_object_manager.html#a25b057e6d1e60c9cbeb29d41923d8c2c", null ],
    [ "Update", "class_object_manager.html#ad1d5fa53d02ab5b7fbf44e1e410c2d71", null ],
    [ "LateUpdate", "class_object_manager.html#a63867ab13ce2d18af1f64d4a6c5d01f9", null ],
    [ "Render", "class_object_manager.html#a17c5583971e5ddc671ca446e1fe5ca3b", null ],
    [ "CreateActor", "class_object_manager.html#a8f8d1349bde416fbcf567129a11ac985", null ],
    [ "CleanUp", "class_object_manager.html#a114c661547d4b3766ae345f462485ec8", null ],
    [ "SpawnProjectile", "class_object_manager.html#a5846d3d991401e62154006cb4cc874de", null ],
    [ "GeneratePlayArea", "class_object_manager.html#ab519b3a7f5377b8d0768077bdaa3f147", null ],
    [ "_PushGameObject", "class_object_manager.html#a38dabcbc44803ffd70f1bda7eabf8963", null ],
    [ "_MergeNewGameObjects", "class_object_manager.html#a3e00ee64b6a4b91f879f4aa63d4be326", null ],
    [ "game_objects_", "class_object_manager.html#aaa88a8cd4b8acca953f8bb12644d89c0", null ],
    [ "new_game_objects_", "class_object_manager.html#a17afa2b8f96d2db91ca4a55831c29a3a", null ],
    [ "play_area_", "class_object_manager.html#a88e44690aa83f73d3b8907d869381e2c", null ]
];