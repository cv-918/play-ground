var class_i_updatable =
[
    [ "IUpdatable", "class_i_updatable.html#a73c88a34c0e0d5339d57807a6f477974", null ],
    [ "~IUpdatable", "class_i_updatable.html#a6818cac55ff50ed056584f4ab5a0de49", null ],
    [ "Update", "class_i_updatable.html#a243d9557f7a263da91c8a9df2537bd8a", null ],
    [ "LateUpdate", "class_i_updatable.html#adaa4dcf83232f501ec5ba05facbb42c8", null ],
    [ "Render", "class_i_updatable.html#a3e5d8dac1580b8c342e87b5f7d93a42b", null ],
    [ "Activate", "class_i_updatable.html#a91f4aef10efae529db87651a27d14757", null ],
    [ "InActivate", "class_i_updatable.html#abfca93036fb6d4253bf608f90d51a7ad", null ],
    [ "IsActive", "class_i_updatable.html#a218a8d5a3ee19dffa1521539bcf1ee43", null ],
    [ "IsEnable", "class_i_updatable.html#aa0cffd508937590aced7d786ad276ce8", null ],
    [ "SetEnable", "class_i_updatable.html#aa385fee7cb803b6f4eb4ecfc1645d48d", null ],
    [ "IsVisible", "class_i_updatable.html#afe18a506e1f5962aaf0be699d66baaf2", null ],
    [ "SetVisible", "class_i_updatable.html#a21a530fd8373d49c579fc3595f1b794e", null ],
    [ "is_enable_", "class_i_updatable.html#a5e53280e96d95fadad948f3c1e1db1b8", null ],
    [ "is_visible_", "class_i_updatable.html#a0a79641a32644372d98dec50b7b9a4d0", null ]
];