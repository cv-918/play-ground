var class_collision_manager =
[
    [ "Update", "class_collision_manager.html#a23c21d077dbfd7ca86e7c0649d775dfc", null ],
    [ "SetCollisionLayer", "class_collision_manager.html#a8697a84a95f2d2b6939c0f4c13e164e2", null ],
    [ "RegisterCollider", "class_collision_manager.html#a2e17973e4d1ae066a796970ade2ee2e2", null ],
    [ "DeregisterCollider", "class_collision_manager.html#aba5e5ed7c6180aebe22654203ad9417d", null ],
    [ "ClearAllColliders", "class_collision_manager.html#ab48e50c6dc9cbc776173f047defa6c7c", null ],
    [ "_IsColliding", "class_collision_manager.html#a6e687674b7e56444fbfff5c8e38750f4", null ],
    [ "layer_colliders_", "class_collision_manager.html#a6e748ab45d55ada9e4ec27b61b1ce3b4", null ],
    [ "collision_matrix_", "class_collision_manager.html#a4b113a67d94265f3a2a2d07d46a8c020", null ]
];