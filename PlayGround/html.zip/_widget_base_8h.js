var _widget_base_8h =
[
    [ "WidgetBase", "class_widget_base.html", "class_widget_base" ]
];