var _stage_json_data_manager_8h =
[
    [ "_StageDataMgr", "_stage_json_data_manager_8h.html#a425f725145b69f69a5a1993bbaca3c53", null ],
    [ "NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE", "_stage_json_data_manager_8h.html#a3873c3b9ded4367c2cf65495ee04d5e4", null ],
    [ "id_", "_stage_json_data_manager_8h.html#a61b5c70903d9caf7cfd3db01dc2e0601", null ],
    [ "weight_", "_stage_json_data_manager_8h.html#a4ebb5fbdeda6e62d21528b7deb407c19", null ]
];