var class_timer =
[
    [ "Initialize", "class_timer.html#a919bf93db08829d54b07bab7a7041db3", null ],
    [ "Update", "class_timer.html#a77a6595649759e7236d1b43c2c10e16b", null ],
    [ "DeltaTime", "class_timer.html#a5518b52188091d1e0ad71e46bde242f0", null ],
    [ "TotalTime", "class_timer.html#aebd04b84aba84cd703b55680db67d3a8", null ],
    [ "FPS", "class_timer.html#a5695a644ffd5f63dc093c9e00d58ed90", null ],
    [ "frequency_", "class_timer.html#a1707d5305fbe5fb5dcedc5cfc0ad0a7c", null ],
    [ "prev_count_", "class_timer.html#a6a268c52885fe43d27825a806eeebecf", null ],
    [ "delta_time_", "class_timer.html#a33461299c7c107c2fafeadf38defafd1", null ],
    [ "total_time_", "class_timer.html#a0dec8efa211aab0cb361e3d15de6fc6c", null ],
    [ "fps_timer_", "class_timer.html#a90231dc609b5ac79fb412f73d3be1fe2", null ],
    [ "fps_count_", "class_timer.html#ac84b3aef42299bb985d9e231196e03ff", null ],
    [ "fps_", "class_timer.html#a06ff38b30c5a9c41d069133073d1097a", null ]
];