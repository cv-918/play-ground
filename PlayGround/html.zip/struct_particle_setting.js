var struct_particle_setting =
[
    [ "id_", "struct_particle_setting.html#a17e0c194ba72a54d1966a7addbf3578b", null ],
    [ "shape", "struct_particle_setting.html#acff44b7f221ac54b1dcc50a6bfdf6516", null ],
    [ "shapeRadius", "struct_particle_setting.html#aa5968c0d36bce87f4088ef33a7de99ef", null ],
    [ "arcAngle", "struct_particle_setting.html#a1c4468a9dc7a71349911635a5a4beb1a", null ],
    [ "minLife", "struct_particle_setting.html#a143bd25d2e2375e260f33029cf337c30", null ],
    [ "maxLife", "struct_particle_setting.html#aec6e2d2d7412372ab43402ee78f23c9a", null ],
    [ "minSpeed", "struct_particle_setting.html#a4792cf62035a57a83c51564b7e6962a0", null ],
    [ "maxSpeed", "struct_particle_setting.html#aada098ef618c5a651ae0b16d1a584a54", null ],
    [ "startScale", "struct_particle_setting.html#a56b85216ea51c98c2a0df9ad2739a8b0", null ],
    [ "sizeEase", "struct_particle_setting.html#a31adc832260e9832338b1a6a9efa6519", null ],
    [ "endScale", "struct_particle_setting.html#a97da020f7129d5a3cf0bd34b6a08ec50", null ],
    [ "colorEase", "struct_particle_setting.html#aa8aa29468e2b67a507f02a1835f1f54b", null ],
    [ "startColor", "struct_particle_setting.html#a11c668a6bcdbabcbd331d834b565e68c", null ],
    [ "endColor", "struct_particle_setting.html#a1d31dac54ff9feaf72b9e8bdb180fccd", null ],
    [ "airResistance", "struct_particle_setting.html#a03d6db21a47457520d74944a500d4798", null ],
    [ "gravityScale", "struct_particle_setting.html#ae233b5f8bbc94669c5fa3fe574c91ddc", null ],
    [ "textureKey", "struct_particle_setting.html#a09d630f4e328bb5210b9170c5a70c572", null ]
];