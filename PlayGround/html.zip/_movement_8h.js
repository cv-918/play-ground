var _movement_8h =
[
    [ "Movement", "class_movement.html", "class_movement" ],
    [ "MovementControlMode", "_movement_8h.html#aec3beb325e69e083afbe6f16d5b37310", [
      [ "Normal", "_movement_8h.html#aec3beb325e69e083afbe6f16d5b37310a960b44c579bc2f6818d2daaf9e4c16f0", null ],
      [ "Dash", "_movement_8h.html#aec3beb325e69e083afbe6f16d5b37310a3663598d5c5858b5a6040b1bbed4f187", null ]
    ] ],
    [ "DashImpulsePolicy", "_movement_8h.html#a5184086d4bbb9c6d49d78467b3501d72", [
      [ "Additive", "_movement_8h.html#a5184086d4bbb9c6d49d78467b3501d72a3f7b3d8ee7bf0d542bd50821c083888f", null ],
      [ "IgnoreImpulse", "_movement_8h.html#a5184086d4bbb9c6d49d78467b3501d72a4e0cbc3aebf797cda699e85ff04b2e91", null ],
      [ "CancelDashOnImpulse", "_movement_8h.html#a5184086d4bbb9c6d49d78467b3501d72a4d04bc1a74d2f7fa7f1e100403ccfb77", null ]
    ] ]
];