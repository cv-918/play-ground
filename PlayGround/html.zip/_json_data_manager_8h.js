var _json_data_manager_8h =
[
    [ "JsonDataManager&lt; T &gt;", "class_json_data_manager.html", "class_json_data_manager" ],
    [ "json", "_json_data_manager_8h.html#ab701e3ac61a85b337ec5c1abaad6742d", null ]
];